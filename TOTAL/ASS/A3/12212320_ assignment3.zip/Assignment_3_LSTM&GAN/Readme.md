# CS324: Deep Learning Assignment 3

## Part 1

- Run Part_1.ipynb or lstm.py.

## Part_2

- Run Three notebook file or my_gan.py.
- Images is in folder images.
